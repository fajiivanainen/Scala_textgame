package o1.MinosLabyrinth

class Adventure {

  // The title of the adventure game. */
  val title = "Minotaur's labyrinth"

  private var entry        = new Area("Entry", "You are in a dark big room. Your footsteps are echoing. \nMonster is growling in the distance.\nYou see a red yarn going east. \nIt's probably Ariadne's thread which leads to Theseus.")
  private val treasury     = new Area("Treasury", "You enter a large shining hall. \nEverything around you is made of gold.\nThe red yarn is going north and south.")
  private val crossroads   = new Area("Crossroads", "You find yourself in room with exits to each direction.")
  private val nest         = new Area("Minotaurs nest", "You enter a small cave full of human bones. \nIt smells like rotten flesh.")
  private val tomb         = new Area("Tomb", "There are a lot of skulls and spider webs here. \nYou see a black tombstone in the middle.\nThe red yarn is going east and west.")
  private val tunnel1      = new Area("Tunnel", "You are in a dark tunnel. The air is a bit moist and the atmosphere is sinister. \nYou feel creeps in your spine. \nThe red yarn is going east and west.")
  private val tunnel2      = new Area("Tunnel", "Darkness surrounds you. It's so silent you can hear your blood pumping in your veins. \nThe red yarn is going east and west.")
  private val tunnel3      = new Area("Tunnel", "You are in a dark tunnel. The ceiling is filled with spider webs. \nYou feel creeps in your spine. ")
  private val tunnel4      = new Area("Tunnel", "Once again you enter a tunnel. The darkness is becoming unbearable. \nPanic is starting to form within you.")
  private val tunnel5      = new Area("Tunnel", "The tunnel keeps decending, and the air is becoming hard to breath. \nYou smell something weird")
  private val corner1      = new Area("Corner", "The tunnel is turning.\nThe red yarn is going south and west")
  private val corner2      = new Area("Corner", "The tunnel turns to the left. It's so dark you can't see anything.")
  private val deadend      = new Area("Deadend", "You are in a deadened surrounded by walls. \nYou have to go back.")
  private val well         = new Area("Well", "In the dark you stumbled and fell to a bottomless well.")
  private val mirrorroom   = new Area("Mirror Room", "You enter a room full of mirrors. You see countless reflections. \nBut are all of them yours..?")
  private val opening      = new Area("Opening", "The room is suddenly filled with daylight. You look up and see the sky far above you. \nYou are standing at the bottom of a city well.\nThe red yarn is going north and south.")
  private val dancefloor   = new Area("Dance floor", "You enter a dark room blinking with bright colored disco lights. \nThe bass-boosted music is so loud that you can't hear a thing. \nYou'd better start dancing.")
  private val battlefield  = new Area("Battlefield", "This room is filled with broken armours of late soldiers. \nIn the middle you see the body of Theseus. The red yarn, coming from north, leads straight to his pocket.")
  private val smallroom    = new Area("Small room", "The roof lowers down so much that you can't stand straight. \nThe walls are closing each other. You can barely breath.")
  private val umbrellacave = new Area("Umbrella cave", "You enter a moist cave. Looking up you realize that there are countless umbrellas hanging from the ceiling. \nYou wonder if it rains often down here.")
  private val outside      = new Area("Outside", "Now that the Minotaur's dead, the door was open and you find yourself outside the labyrinth. \nFresh air feels good on your skin.")


         entry.setNeighbors(Vector(                        "east" -> tomb                                                      ))
          tomb.setNeighbors(Vector(                        "east" -> tunnel1,    "south" -> tunnel3,      "west" -> entry      ))
       tunnel1.setNeighbors(Vector(                        "east" -> tunnel2,                             "west" -> tomb       ))
       tunnel2.setNeighbors(Vector(                        "east" -> corner1,                             "west" -> tunnel1    ))
       tunnel3.setNeighbors(Vector("north" -> tomb,                              "south" -> crossroads                         ))
       corner1.setNeighbors(Vector(                                              "south" -> treasury,     "west" -> tunnel2    ))
    crossroads.setNeighbors(Vector("north" -> tunnel3,     "east" -> mirrorroom, "south" -> deadend,      "west" -> corner2    ))
       corner2.setNeighbors(Vector("east" -> crossroads, "south" -> well                               ))
          well.setNeighbors(Vector("north" -> corner2                                                                          ))
       deadend.setNeighbors(Vector("north" -> crossroads                                                                       ))
      treasury.setNeighbors(Vector("north" -> corner1,                           "south" -> opening                            ))
    mirrorroom.setNeighbors(Vector(                        "east" -> dancefloor,                          "west" -> crossroads ))
    dancefloor.setNeighbors(Vector(                        "east" -> opening,    "south" -> smallroom,    "west" -> mirrorroom ))
       opening.setNeighbors(Vector("north" -> treasury,                          "south" -> battlefield,  "west" -> dancefloor ))
     smallroom.setNeighbors(Vector("north" -> dancefloor,  "east" -> battlefield,"south" -> umbrellacave                       ))
   battlefield.setNeighbors(Vector("north" -> opening,                                                    "west" -> smallroom  ))
  umbrellacave.setNeighbors(Vector("north" -> smallroom,                                                  "west" -> tunnel4    ))
       tunnel4.setNeighbors(Vector(                        "east" -> umbrellacave,                        "west" -> tunnel5    ))
       tunnel5.setNeighbors(Vector(                        "east" -> tunnel4,                             "west" -> nest       ))
          nest.setNeighbors(Vector(                        "east" -> tunnel5                                                   ))

  private val minotaurus = new Minotaur(nest)
  private val sphinx = new Sphinx
  this.nest.addMinotaur(minotaurus)
  this.crossroads.addSphinx(sphinx)


  this.mirrorroom.addItem(new Item("fatball", "It's a small fatball. You realize that it's full of anesthetic to make the beast sleep. \nTheseus must have dropped it."))
  this.battlefield.addItem(new Item("knife", "It's the famous knife of Theseus.\nIts blade is still as sharp as a physicist."))
  this.opening.addItem(new Item("bucket", "It's a regular plastic bucket from Tokmanni. \nPeople would wait in queues for hours to get one of these."))
  this.treasury.addItem(new Item("stone", "It's the famous Philosopher's stone which turns everything to gold. \nUnfortunately you are included in everything."))


  // The character that the player controls in the game. */
  val player = new Player(entry)

  // The number of turns that have passed since the start of the game. */
  var turnCount = 0
  // The maximum number of turns that this adventure game allows before time runs out. */
  val timeLimit = 100


  // Determines if the adventure is complete, that is, if the player has won. */
  def isComplete = this.minotaurus.isDead && (this.player.location == outside)

  // Determines whether the player has won, lost, or quit, thereby ending the game. */
  def isOver = this.isComplete || this.player.hasQuit || this.player.location == well || this.player.isDead || this.turnCount >= timeLimit

  // Returns a message that is to be displayed to the player at the beginning of the game. */
  def welcomeMessage = "Oh no! King Minos has thrown you to his labyrinth. \nThe entry is sealed with a giant rock. \nThe king won't let you out before the terrible monster Minotaur, a combination of a man and a bull, is dead. \nBut don't worry! The hero Theseus should be somewhere here. Maybe he can help you.\nYou also brought your compass with you so that you won't get lost so easily.\n\nUse command 'help' for help."

// Returns a message that is to be displayed to the player at the end of the game. The message
    /* will be different depending on whether or not the player has completed their quest. */
  def goodbyeMessage = {
    if (this.isComplete)
      "Well done! You've killed the Minotaur and got out of the labyrinth alive. \nNow it's your time to overthrow king Minos."
    else if (this.player.isDead || this.player.location == well)
      "You died! \nGame over."
    else if(this.turnCount >= timeLimit)
      "You got lost in the labyrinth and starved. You should have followed Ariadne's thread. \nGame over."
    else "Rage quit :DD"
  }

  def labyrinthOpens = {
    if(this.minotaurus.isDead) {
      entry = new Area("Entry", "You return to the same room you started from. \nThe rock has disappeared from the door, and the golden rays of the evening sun are shining inside.")
      entry.setNeighbors(Vector(                        "east" -> tomb,                                "west" -> outside    ))
       tomb.setNeighbors(Vector(                        "east" -> tunnel1,    "south" -> tunnel3,      "west" -> entry      ))
    }
  }


  // Plays a turn by executing the given in-game command, such as "go west". Returns a textual
    /* report of what happened, or an error message if the command was unknown. In the latter
    * case, no turns elapse. */
  def playTurn(command: String) = {
    this.labyrinthOpens
    this.player.die()
    if(this.turnCount % 3 == 0 && !(this.minotaurus.location == this.player.location)) this.minotaurus.move()
    val action = new Action(command)
    val outcomeReport = action.execute(this.player)
    if (outcomeReport.isDefined) {
      this.turnCount += 1
    }
    outcomeReport.getOrElse("Unknown command: \"" + command + "\".")
  }
}
