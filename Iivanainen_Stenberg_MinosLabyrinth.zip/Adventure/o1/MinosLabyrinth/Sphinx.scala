package o1.MinosLabyrinth

import scala.util.Random


class Sphinx() {

  private val questions = Vector[String]( "What is that which in the morning goes upon four feet, upon two feet in the afternoon,\nand in the evening upon three?","There are two sisters: \nOne gives birth to the other, and the other, \nin turn, gives birth to the first.","What can bring back the dead; make you cry,\nmake you laugh,\nmake you young; is born in an instant,\nyet lasts a lifetime?","If you feed me with food, I will survive.\nBut if you make me drink water I will perish.","At night they come without being fetched,\nand by day they are lost without being stolen.", "What have I got in my pocket?" )
  private val answers = Vector[String]("person", "night and day","memory", "fire","stars", "ring")
  private val answersAndQuestions = answers.zip(questions).toMap

  var letPlayerMove = false

  def ask: String = questions(Random.nextInt(questions.size))

  def isCorrect(answer: String, question: String): Boolean = {
    if (answers.contains(answer)) {
      question == answersAndQuestions(answer)
    } else false
  }

  def correctAnswer(question: String): String = answers(questions.indexOf(question))


}
