package o1.MinosLabyrinth

import o1._
import scala.util.Random

class Minotaur(var location: Area){

  //private var currentLocation: Option[Area] = None

  var isAsleep = false
  var isDead = false

  def move() = {
    if(!this.isAsleep){
      location.removeMinotaur
      var neighbor: Option[Area] = None
      var directions = Vector("north","east","south","west")
      var index = 0
      while(neighbor.isEmpty) {
        neighbor = location.neighbor(directions(index))
        index += 1
      }
      location = neighbor.getOrElse(location)
      location.addMinotaur(this)
    }
  }

}