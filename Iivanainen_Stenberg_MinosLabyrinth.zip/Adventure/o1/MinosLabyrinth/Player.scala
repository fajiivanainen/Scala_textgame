package o1.MinosLabyrinth

import scala.collection.mutable.Map

class Player(startingArea: Area) {

  private var currentLocation = startingArea        // gatherer: changes in relation to the previous location
  private var quitCommandGiven = false              // one-way flag
  private val items = Map[String, Item]("compass" -> new Item("compass", "It's your dads old compass you brought all the way from home."))
  private var latestQuestion = ""
  private var questionAsked = false

  var isDead = false

  def die() = {
    if(this.location.minotaur.isDefined && !this.items.contains("fatball") && !this.items.contains("knife") && !this.location.minotaur.get.isAsleep) {
      this.isDead = true
    }

  }

  def hasQuit = this.quitCommandGiven

  def location = this.currentLocation

  def permissionToMove: Boolean = {
    if(this.location.minotaur.isDefined) {
      this.location.minotaur.get.isAsleep
    }else if(this.location.sphinx.isDefined) {
      this.location.sphinx.get.letPlayerMove
    }else true
  }

  def go(direction: String) = {
    if (this.permissionToMove){
      if(this.location.sphinx.isDefined) this.location.sphinx.get.letPlayerMove = false
      val destination = this.location.neighbor(direction)
      this.currentLocation = destination.getOrElse(this.currentLocation)
      if (destination.isDefined) "You go " + direction + "." else "You can't go " + direction + "."
    }else "You cannot move."
  }

  def drop(itemName: String): String = {
    if(this.items.contains(itemName)) {
      this.currentLocation.addItem(this.items(itemName))
      this.items.remove(itemName)
      "You drop the " + itemName + "."
    }else "You don't have that!"
  }

  def juggle(itemName: String): String = {
    if (this.items.contains(itemName))  {
      this.drop(itemName)
      "You throw the " + itemName + " to the air, but catch it unsuccessfully. \nMaybe you shouldn't play with your belongins."
    } else "The " + itemName + " is not in your possession. \nPlay with something you have!"
  }

  def examine(itemName: String): String = {
    if (this.items.contains(itemName)) {
      "You look closely at the " + itemName + ".\n" + this.items(itemName).description
    }else "If you want to examine something, you need to pick it up first."
  }

  def get(itemName: String): String = {
    this.currentLocation.removeItem(itemName) match {
      case None => "There is no " + itemName + " here to pick up."
      case Some(item) => {this.items += itemName -> item
        if(itemName == "stone") {
          this.isDead = true
          "You pick up the stone. \nIt's the famous Philosopher's stone which turns everything to gold. \nUnfortunately you are included in everything."
        }else "You pick up the " + itemName + "."
      }
    }
  }

  def use(itemName: String): String = {
    val minotaur = this.location.minotaur
    if(this.items.contains(itemName)) {
      this.items.remove(itemName)
      if(itemName == "fatball" && minotaur.isDefined) {
        minotaur.get.isAsleep = true
        "You throw the fatball into the Minotaur's mouth. \nHe charges at you but falls asleep in the middle of movement.\nNow it is your opportunity to kill it if you have a knife."
      }
      else if(itemName == "knife" && minotaur.isDefined) {
        if(minotaur.get.isAsleep){
          minotaur.get.isDead = true
          "You use the knife, and cut the Minotaurs throat. \nYou see life escaping its body.\n\nThe labyrinth is now open. \nAll you have to do now is to find your way out."
        } else {
          this.isDead = true
          "The Minotaur takes the knife from you and breaks it. \nYou try to fistfight the monster but he quickly overpowers you and kills you. \nWell played! You are now Minotaur's food."
        }
      } else "You use the " +itemName+". \nIt's not very effective"
    } else "You can't use an item you don't have."
  }

  def fight: String = {
    if(this.location.minotaur.isDefined && this.location.minotaur.isDefined) {
      this.isDead = true
      "You start a fight with the monster. \nHe is much bigger and stronger than you. \nThis isn't going to end well."
    } else if(this.location.sphinx.isDefined) {
      this.isDead = true
      "You approach the Sphinx and try to attack her. \nShe stops you easily and throws you to the wall with her giant paw."
    }else "There's no one to fight with."
  }

  def hi: String ={
    if(this.location.sphinx.isDefined && questionAsked == false) {
      questionAsked = true
      latestQuestion = this.location.sphinx.get.ask
     "Hello traveller! I am the Sphinx of the labyrinth. \nIf you want to continue, you have to answer a riddle: \n" + latestQuestion
    } else if(this.location.sphinx.isDefined && questionAsked == true) {
      "Answer the question! \n" + latestQuestion
    } else "Your voice echoes in the labyrinth. \nYou hear the footsteps of a large creature nearby. \nMaybe you should stay quiet."
  }

  def answer(answer: String) = {
    if(this.location.sphinx.isDefined && questionAsked) {
      questionAsked = false
      if(this.location.sphinx.get.isCorrect(answer, latestQuestion)) {
        this.location.sphinx.get.letPlayerMove = true
        "Congratulations traveller. That is the correct answer. \nYou may proceed with your quest. \nMay the odds be ever in your favor."
      }else {
        this.isDead = true
        "You have chosen... \npoorly.\n\nThe correct answer would have been: " + this.location.sphinx.get.correctAnswer(latestQuestion)
      }
    }else "Who are you answering to?"
  }


  def has(itemName: String): Boolean = this.items.contains(itemName)

  def inventory: String = {
    if(this.items.isEmpty) {
      "You are empty-handed."
    }else "You are carrying:\n" + this.items.keys.mkString("\n")
  }

  def quit() = {
    this.quitCommandGiven = true
    ""
  }

  def help() = {
    "Commands: \nhelp -> description of commands\ngo + [direction] -> player moves in a labyrinth to the asked direction \nquit -> quit game \nget + [item] -> grab an item if you see one \ninventory -> a list of all items you are carrying\nexamine + [item] -> examine an item in your inventory \ndrop + [item] -> you drop an item \nuse + [item] -> use an item in your possession \nhi -> say hi \nanswer +[your answer] -> you answer a question if someone poses one \njuggle + [item] -> play with your toys \nfight -> fight"
  }

  override def toString = "Now at: " + this.location.name


}


