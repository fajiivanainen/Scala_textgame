package o1.MinosLabyrinth

import scala.collection.mutable.Map

/** The class `Area` represents locations in a text adventure game world. A game world
  * consists of areas. In general, an "area" can be pretty much anything: a room, a building,
  * an acre of forest, or something completely different. What different areas have in
  * common is that players can be located in them and that they can have exits leading to
  * other, neighboring areas. An area also has a name and a description.
  * @param name         the name of the area
  * @param description  a basic description of the area (typically not including information about items) */
class Area(var name: String, var description: String) {

  private val neighbors = Map[String, Area]()

  private val items = Map[String, Item]()



  var sphinx: Option[Sphinx] = None

  var minotaur: Option[Minotaur] = None


  /** Returns the area that can be reached from this area by moving in the given direction. The result
    * is returned in an `Option`; `None` is returned if there is no exit in the given direction. */
  def neighbor(direction: String) = this.neighbors.get(direction)

  def addItem(item: Item) = this.items += item.name -> item

  def contains(itemName: String): Boolean = this.items.contains(itemName)

  def removeItem(itemName: String): Option[Item] = {
    val item = this.items.get(itemName)
    this.items.remove(itemName)
    item
  }

  def addSphinx(sp: Sphinx) = this.sphinx = Some(sp)

  def addMinotaur(min: Minotaur) = this.minotaur = Some(min)

  def removeMinotaur = this.minotaur = None

  def removeSphinx = this.sphinx = None


  /** Adds an exit from this area to the given area. The neighboring area is reached by moving in
    * the specified direction from this area. */
  def setNeighbor(direction: String, neighbor: Area) = {
    this.neighbors += direction -> neighbor
  }


  /** Adds exits from this area to the given areas. Calling this method is equivalent to calling
    * the `setNeighbor` method on each of the given direction--area pairs.
    * @param exits  contains pairs consisting of a direction and the neighboring area in that direction
    * @see [[setNeighbor]] */
  def setNeighbors(exits: Vector[(String, Area)]) = {
    this.neighbors ++= exits
  }


  /** Returns a multi-line description of the area as a player sees it. This includes a basic
    * description of the area as well as information about exits and items. The return
    * value has the form "DESCRIPTION\n\nExits available: DIRECTIONS SEPARATED BY SPACES".
    * The directions are listed in an arbitrary order. */
  def fullDescription = {
    val exitList = "\n\nExits available: " + this.neighbors.keys.mkString(" ")
    val itemList = "\nYou see here: " + this.items.keys.mkString(" ")
    var sphinxRules = ""
    var minotaurRules = ""
    if(this.sphinx.isDefined) sphinxRules = "\n\nGASP! In the middle of everything is a behemoth Sphinx. \nIf you want to continue, you have to answer a question. \nIf you get it wrong, she'll kill you. \nBut no pressure, say hi to her!"
    if(this.minotaur.isDefined) {
      if(!this.minotaur.get.isAsleep) minotaurRules = "\n\nWOAH!! The raging minotaur is right in front of you. This is not a fight you can win. \nIf you have a fatball with you, use it by throwing it in his mouth to make him fall asleep. \nThen you can use knife to cut his throat. \nIf you don't have them with you, congratulations! \nYou are Minotaur-food."
      else minotaurRules = "\n\nThe beast is asleep in the middle of the room. \nNow it is your time to strike."
    }
    this.description + itemList + exitList + minotaurRules + sphinxRules
  }


  /** Returns a single-line description of the area for debugging purposes. */
  override def toString = this.name + ": " + this.description.replaceAll("\n", " ").take(150)



}
